// importação de routes
//import AppRoutes from './routes/AppRoutes'
import Login from "./pages/Login"
import Cadastro from "./pages/Cadastro"
import CriarTarefa from "./pages/criarTarefa"

function App() {


  return (
    <div className="App">
      <h1>teste</h1>
      {/* // Renderiza as rotas, que vão mostrar os componentes de acordo com a URL. */}
    {/* { <AppRoutes/> } */}
      <Login/>
    <Cadastro/> 
    <CriarTarefa/>
  </div>
  )
}

export default App
