import { useState } from "react";

function Login() {
    const [email, setEmail] = useState('');
    const [senha, setSenha] = useState('');
    // consoles para fins de testes 

        // loguin de teste
        // "email":"joao@email.com",
        // "senha":"1234"
   
   async function handleSubmit (event) {
    event.preventDefault(); 
    try {
        const resposta = await fetch('http://localhost:3000/login',{
            method: 'Post',
            headers:{
                'Content-Type': 'application/json',  // Define que os dados enviados são JSON'
            },
            body: JSON.stringify({
                email,
                senha
            })
        });
        const dados = await resposta.json();
        if(resposta.ok){
            console.log("Login bem-sucedido:", dados);
            // Aqui você pode salvar o token no localStorage, por exemplo
            // localStorage.setItem("token", dados.token);
        }else {
            console.error("Erro no login:", dados.mensagem);
            // Aqui você pode mostrar a mensagem de erro na tela
          }
    } catch (error) {
        console.error("Erro na requisição:", erro);
    }

    }

    return (
        <div>
            <h2>Login</h2>
            <form onSubmit={handleSubmit}>
                <input
                    type="email"
                    placeholder="Digite seu e-mail"
                    value={email}
                    onChange={(apelido) => setEmail(apelido.target.value)}
                />

                <input
                    type="password"
                    placeholder="digite sua senha"
                    value={senha}
                    onChange={(event) => setSenha(event.target.value)}
                />

                <button type="submit">Entrar</button>
            </form>
        </div>
    );
}

export default Login;

// nota loguin testado e realizado com sucesso