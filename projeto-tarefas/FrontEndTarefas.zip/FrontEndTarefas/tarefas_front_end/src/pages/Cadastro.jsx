import { useState } from "react";

function Cadastro() {
    const [nome, setNome] = useState('');
    const [email, setEmail] = useState('');
    const [senha, setSenha] = useState('');
    // consoles para fins de testes 

        // loguin de teste
        // "email":"joao@email.com",
        // "senha":"1234"
   
   async function handleSubmit (event) {
    event.preventDefault(); 
    try {
        const resposta = await fetch('http://localhost:3000/usuarios',{
            method: 'Post',
            headers:{
                'Content-Type': 'application/json',  // Define que os dados enviados são JSON'
            },
            body: JSON.stringify({
                nome,
                email,
                senha
            })
        });
        const dados = await resposta.json();
        if(resposta.ok){
            console.log("Cadastro bem sucedido:", dados);
            // Aqui você pode salvar o token no localStorage, por exemplo
            // localStorage.setItem("token", dados.token);
        }else {
            console.error("Erro no cadastro:", dados.mensagem);
            // Aqui você pode mostrar a mensagem de erro na tela
          }
    } catch (error) {
        console.error("Erro na requisição:", erro);
    }

    }

    return (
        <div>
            <h2>Cadastro</h2>
            <form onSubmit={handleSubmit}>
            <input
                    type="nome"
                    placeholder="Digite seu nome"
                    value={nome}
                    onChange={(apelido) => setNome(apelido.target.value)}
                />
                <input
                    type="email"
                    placeholder="Digite seu e-mail"
                    value={email}
                    onChange={(apelido) => setEmail(apelido.target.value)}
                />

                <input
                    type="password"
                    placeholder="digite sua senha"
                    value={senha}
                    onChange={(event) => setSenha(event.target.value)}
                />

                <button type="submit">Entrar</button>
            </form>
        </div>
    );
}

export default Cadastro;

// nota loguin testado e realizado com sucesso