import { useState } from "react";

function CriarTarefa() {
    const [titulo, setTitulo] = useState('');
    const [descricao, setDescricao] = useState('');
    const token = localStorage.getItem('token');
    // consoles para fins de testes 

        // loguin de teste
        // "email":"joao@email.com",
        // "senha":"1234"
   
   async function handleSubmit (event) {
    event.preventDefault(); 
    try {
        const resposta = await fetch('http://localhost:3000/tarefas',{
            method: 'Post',
            headers:{
                'Content-Type': 'application/json',  // Define que os dados enviados são JSON'
                'Authorization': `Bearer ${'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Miwia…xMTh9.ug_Cvmtrx28dpCZLTkT-OE0HEw0zUTQMIc-BKK-rzxM'}`
            },
            body: JSON.stringify({
                titulo,
                descricao
            })
        });
        const dados = await resposta.json();
        if(resposta.ok){
            console.log("Tarefa adicionada:", dados);
            // Aqui você pode salvar o token no localStorage, por exemplo
            // localStorage.setItem("token", dados.token);
        }else {
            console.error("Erro na tarefa:", dados.mensagem);
            // Aqui você pode mostrar a mensagem de erro na tela
          }
    } catch (error) {
        console.error("Erro na requisição:", erro);
    }

    }

    return (
        <div>
            <h2>Criar Tarefa</h2>
            <form onSubmit={handleSubmit}>
            <input
                    type="Titulo"
                    placeholder="Titulo da Tarefa"
                    value={titulo}
                    onChange={(apelido) => setTitulo(apelido.target.value)}
                />
                <input
                    type="Descrição"
                    placeholder="Digite sua descrição"
                    value={descricao}
                    onChange={(apelido) => setDescricao(apelido.target.value)}
                />

                <button type="submit">Entrar</button>
            </form>
        </div>
    );
}

export default CriarTarefa;

// nota loguin testado e realizado com sucesso